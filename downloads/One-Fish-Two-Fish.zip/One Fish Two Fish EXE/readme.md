# Thanks for downloading!

I came up with this idea on thursday night and basically started from scratch when I couldn't get the previous idea to work <br>
so this was basically made in two days<br>
I was thinking about having different color fish when I remembered the book <i>one fish two fish red fish blue fish</i> by dr seuss<br><br>
I know this game isn't the most polish but I hope you enjoy it :>

# how to run

run `OFTF.exe`

`(RUNNING GAME.PY WILL NOT WORK)`<br>
`EXE MIGHT NOT WORK BECAUSE PYINSTALLER SUCKS`

### Overall Idea of the game

Basically there are fish trapped in water pipes and you basically have to use some fish food to guide them out

### controls

`click and drag` to move the food around, if the food is close enough to the fish, the fish will go towards it

### assets

all art and code where done by me (hammish47)<br>
sound effects generated with https://sfxr.me/ <br>
music is space fighter loop by Kevin MacLeod (the royalty free god) https://incompetech.com/
